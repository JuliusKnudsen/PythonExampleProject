import functools
from psycopg2 import sql

from flask import (Blueprint, flash, g, redirect, render_template, request,
                   session, url_for)

from msp.db import get_db
from msp.index import login_required

bp = Blueprint("main", __name__, url_prefix="/main")


@bp.route('/welcome')
@login_required
def welcome():
    return render_template("main/welcome.html")


@bp.route('/create/meal', methods=('GET', 'POST'))
@login_required
def createMeal():
    db = get_db()
    db_cur = db.cursor()

    query_ingredients = sql.SQL("""SELECT * FROM {table}""").format(
        table=sql.Identifier('ingredient')
    )

    db_cur.execute(query_ingredients)
    ingredients = db_cur.fetchall()

    if request.method == 'POST':
        _mealname = request.form["meal-name"]
        _mealrecipe = request.form["meal-recipe"]
        _mealtype = request.form["meal-type"]

        insert_meal = sql.SQL("""INSERT INTO {table} (mname, mtype) VALUES (%s, %s) RETURNING mid;""").format(
            table=sql.Identifier('meal')
        )

        db_cur.execute(insert_meal, (_mealname, _mealtype))
        meal_id = db_cur.fetchone()[0]  # Get mID of the last insert

        insert_recipe = sql.SQL("""INSERT INTO {table} (bodytext) VALUES (%s) RETURNING rid;""").format(
            table=sql.Identifier('recipe')
        )

        db_cur.execute(insert_recipe, (_mealrecipe,))
        recipe_id = db_cur.fetchone()[0]

        link_meal_recipe = sql.SQL("""INSERT INTO {table} (mid, rid) VALUES (%s, %s);""").format(
            table=sql.Identifier('meal_recipe')
        )

        db_cur.execute(link_meal_recipe, (meal_id, recipe_id))

        # Extract ingredient IDs, omitting empty ingredients
        ingr = []
        for i in range(0, 6):
            tmp = request.form[f"ingr-{i+1}"]
            if tmp != "":
                tmp = tmp.strip().split(":")
                amg = request.form[f"amount-g-{i+1}"]
                ing = (tmp[0], recipe_id, amg)  # (ing-ID, recipe-ID, amount)
                ingr.append(ing)

        link_ingredients_recipe = sql.SQL("""INSERT INTO {table} (iid, rid, amount) VALUES (%s, %s, %s);""").format(
            table=sql.Identifier('ingredient_recipe')
        )

        db_cur.executemany(link_ingredients_recipe, ingr)

        user_id = g.user

        link_employee_meal = sql.SQL("""INSERT INTO {table} (mid, ecpr) VALUES (%s, %s);""").format(
            table=sql.Identifier('employee_meals')
        )

        db_cur.execute(link_employee_meal, (meal_id, user_id[0]))

        db.commit()
        flash(
            f"Du har oprettet en ny måltid {_mealname} med ID {meal_id}!", "success")

    return render_template("main/create/createMeal.html", ingredients=ingredients)


@bp.route('/create/plan', methods=('GET', 'POST'))
@login_required
def createPlan():
    db = get_db()
    db_cur = db.cursor()

    query_meals = sql.SQL("""SELECT mid, mname, mtype, efirstname, elastname 
                                   FROM {meals} 
                                        NATURAL JOIN {employee_meals} 
                                        NATURAL JOIN {employee} 
                                        ORDER BY {col}""").format(
        meals=sql.Identifier('meal'),
        employee_meals=sql.Identifier('employee_meals'),
        employee=sql.Identifier('employee'),
        col=sql.Identifier('mid')
    )

    db_cur.execute(query_meals)
    meals = db_cur.fetchall()

    if request.method == 'POST':
        _planname = request.form["plan-name"]
        _plantype = request.form["plan-type"]
        _meallsit = request.form["meal-list"]

        meal_IDs = list(map(int, _meallsit.strip().split(",")))

        create_plan = sql.SQL("""INSERT INTO {table} (dtitle, dtype) 
                                 VALUES (%s, %s)
                                 RETURNING did;""").format(
            table=sql.Identifier('dietaryplan')
        )

        db_cur.execute(create_plan, (_planname, _plantype))
        plan_ID = db_cur.fetchone()[0]

        plan_IDs = [plan_ID for i in range(len(meal_IDs))]
        # [(meal1, plan), ... , (mealn, plan)]
        vals = list(zip(meal_IDs, plan_IDs))

        link_meals_plan = sql.SQL("""INSERT INTO {table} (mid, did) VALUES (%s, %s)""").format(
            table=sql.Identifier("meal_dietaryplan")
        )
        db_cur.executemany(link_meals_plan, vals)

        link_employee_plan = sql.SQL("""INSERT INTO {table} (ecpr, did) VALUES (%s,%s)""").format(
            table=sql.Identifier('employee_dietaryplan')
        )
        db_cur.execute(link_employee_plan, (g.user[0], plan_ID))

        db.commit()
        flash(
            f"Du har oprettet en ny kostplan {_planname} med ID {plan_ID}!", "success")

    return render_template("main/create/createPlan.html", meals=meals)


@bp.route('/assign', methods=('GET', 'POST'))
@login_required
def assignPlan():
    db = get_db()
    db_cur = db.cursor()

    if request.method == 'POST':
        _patient_cpr = request.form["pcpr"]
        _plan_list = request.form["plan-list"]

        plan_IDs = list(map(int, _plan_list.strip().split(",")))
        patient_CPRs = [_patient_cpr for i in range(len(plan_IDs))]

        sql_assign_plans = sql.SQL(
            """INSERT INTO {pd} (did, pcpr) VALUES (%s, %s)"""
        ).format(
            pd=sql.Identifier("patient_dietaryplan")
        )

        vals = list(zip(plan_IDs, patient_CPRs))

        db_cur.executemany(sql_assign_plans, vals)
        db.commit()
        print(patient_CPRs)
        print(plan_IDs)
        print(vals)

    query_my_patients = sql.SQL(
        """SELECT pda.pfirstname, 
                pda.plastname, 
                pda.pcpr, 
                String_agg(did :: text, ' ') AS "plan_list", 
                pda.pemployee 
            FROM   (SELECT p.pfirstname, 
                        p.plastname, 
                        p.pcpr, 
                        pd.did, 
                        p.pemployee 
                    FROM   {patient} AS p 
                        LEFT JOIN {pd} AS pd 
                                ON p.pcpr = pd.pcpr) AS pda 
            GROUP  BY pda.pcpr, 
                    pda.pemployee, 
                    pda.pfirstname, 
                    pda.plastname 
            HAVING pda.pemployee = (%s)
            ORDER BY pda.pcpr""").format(
        patient=sql.Identifier("patient"),
        pd=sql.Identifier("patient_dietaryplan")
    )

    db_cur.execute(query_my_patients, (g.user[0],))
    my_patients = db_cur.fetchall()

    query_dietery_plans = sql.SQL(
        """SELECT * FROM {table}"""
    ).format(table=sql.Identifier('dietaryplan'))

    dietary_plans = db_cur.execute(query_dietery_plans)
    plans = db_cur.fetchall()

    return render_template("main/create/assignPlan.html", patients=my_patients, plans=plans)


@bp.route('update/meal', methods=('GET',))
@login_required
def updateMealHome():
    db = get_db()
    db_cur = db.cursor()

    query_meals = sql.SQL(
        """ SELECT mid, mname, mtype, efirstname, elastname 
            FROM {meals} NATURAL JOIN {employee_meals} 
                        NATURAL JOIN {employee}
            WHERE {employee}.ecpr = (%s)
            ORDER BY {col}
        """).format(
            meals=sql.Identifier('meal'),
            employee_meals=sql.Identifier('employee_meals'),
            employee=sql.Identifier('employee'),
            col=sql.Identifier('mid')
    )

    db_cur.execute(query_meals, (g.user[0],))
    meals = db_cur.fetchall()

    return render_template("main/update/updateMealHome.html", meals=meals)


@bp.route('update/meal/<meal_id>', methods=('GET', 'POST'))
@login_required
def updateMeal(meal_id):
    db = get_db()
    db_cur = db.cursor()

    query_meal_info = sql.SQL(
        """SELECT mName, mType, bodytext, rID FROM {m} NATURAL JOIN {mr} NATURAL JOIN {r} WHERE {m}.mID = (%s)""").format(
            m=sql.Identifier('meal'),
            mr=sql.Identifier('meal_recipe'),
            r=sql.Identifier('recipe')
    )

    db_cur.execute(query_meal_info, (meal_id,))
    (mName, mType, mRecipe, rID) = db_cur.fetchone()

    query_used_ingredients = sql.SQL(
        """SELECT iID, iName, amount FROM {i} NATURAL JOIN {ir} NATURAL JOIN {mr} WHERE {mr}.mid = (%s)"""
    ).format(
        i=sql.Identifier('ingredient'),
        ir=sql.Identifier('ingredient_recipe'),
        mr=sql.Identifier('meal_recipe')
    )
    db_cur.execute(query_used_ingredients, (meal_id,))
    ingrs = db_cur.fetchall()

    ams = [i[2] for i in ingrs]  # [amount]
    ams += [0] * (6 - len(ams))
    iids_names = [i[:2] for i in ingrs]  # [(iid, iname)]
    ingr_IDs = [i[0] for i in ingrs]  # [iid]

    query_unused_ingredients = sql.SQL(
        """ SELECT * 
            FROM
	            (SELECT ingredient.iid, ingredient.iname FROM ingredient) as ings
            EXCEPT
                (SELECT i.iid, i.iName	
                 FROM	ingredient i NATURAL JOIN 
                        ingredient_recipe ir NATURAL JOIN
                        meal_recipe mr
                 WHERE mr.mID = (%s))
            ORDER BY iid""")

    db_cur.execute(query_unused_ingredients, (meal_id,))
    unused_ingredients = db_cur.fetchall()

    used_ingrs = [(ingrs[i][0], ingrs[i][1], True) for i in range(len(ingrs))]
    all_ingrs = used_ingrs + [(unused_ingredients[i][0], unused_ingredients[i][1], False)
                              for i in range(len(unused_ingredients))]

    if request.method == 'POST':
        if request.form["submit_button"] == "update":
            _mealname = request.form["meal-name"]
            _mealrecipe = request.form["meal-recipe"]
            _mealtype = request.form["meal-type"]

            update_meal = sql.SQL("""UPDATE {table} SET mName=(%s), mType=(%s) WHERE mID = (%s)""").format(
                table=sql.Identifier('meal')
            )

            update_recipe = sql.SQL("""UPDATE {table} SET bodytext=(%s) WHERE rID=(%s)""").format(
                table=sql.Identifier('recipe')
            )

            delete_old_ingrs = sql.SQL("""DELETE FROM {ir} WHERE {ir}.rid = (%s)""").format(
                ir=sql.Identifier('ingredient_recipe')
            )
            old_ingr = ingrs
            new_ingr = []
            for i in range(0, 6):
                tmp = request.form[f"ingr-{i+1}"]
                if tmp != "":
                    tmp = tmp.strip().split(":")
                    amg = request.form[f"amount-g-{i+1}"]
                    ing = (tmp[0], rID, amg)  # (ing-ID, recipe-ID, amount)
                    new_ingr.append(ing)

            link_ingredients_recipe = sql.SQL("""INSERT INTO {table} (iid, rid, amount) VALUES (%s, %s, %s);""").format(
                table=sql.Identifier('ingredient_recipe')
            )

            db_cur.execute(delete_old_ingrs, (rID,))
            db_cur.executemany(link_ingredients_recipe, new_ingr)
            db_cur.execute(update_meal, (_mealname, _mealtype, meal_id))
            db_cur.execute(update_recipe, (_mealrecipe, rID))
            db.commit()

            return redirect(url_for('main.updateMealHome'))

        elif request.form["submit_button"] == "delete":

            query_delete_meal = sql.SQL("""DELETE FROM {m} WHERE mID = (%s)""").format(
                m=sql.Identifier('meal')
            )
            db_cur.execute(query_delete_meal, (meal_id,))
            db.commit()

            flash(f"Måltid med ID {meal_id} er nu blevet slettet!", 'info')
            return redirect(url_for('main.updateMealHome'))

    return render_template(
        "main/update/updateMeal.html",
        meal_id=meal_id,
        meal_name=mName,
        meal_type=mType,
        meal_recipe=mRecipe,
        ingredients=all_ingrs,
        ams=ams
    )