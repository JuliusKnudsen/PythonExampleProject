import os

from flask import Flask, render_template
from flask_bootstrap import Bootstrap
from flask_nav import Nav
from flask_nav.elements import Navbar, View, Separator, Subgroup

def page_not_found(e):
    return render_template("404.html"), 404

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(SECRET_KEY='dev')
    if test_config is None:
        app.config.from_pyfile('config.py', silent=True)    
    else:
        app.config.from_mapping(test_config)
        
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
        
    nav = Nav()
    nav.register_element('nav', Navbar(
        View("Hjem", "main.welcome"),
        Subgroup("Opret",
            View("Måltid", "main.createMeal"),
            View("Kostplan", "main.createPlan")),
        View("Tildel kostplan", "main.assignPlan"),
        Subgroup("Opdater",
            View("Måltid", "main.updateMealHome")),
        View("Log ud", "index.logout"),
    ))
    
    app.register_error_handler(404, page_not_found)
    
    from . import index
    app.register_blueprint(index.bp)
    
    from . import main 
    app.register_blueprint(main.bp)
    
    from . import db
    db.init_app(app)
    
    nav.init_app(app)
    
    Bootstrap(app)
    return app
