import functools
from psycopg2 import sql

from flask import (Blueprint, flash, g, redirect, render_template, request,
                   session, url_for)

from msp.db import get_db

bp = Blueprint('index', __name__)

@bp.route('/', methods=(['GET', 'POST']))
def index():
    if request.method == 'POST':
        cpr = request.form["cpr"]
        password = request.form["password"]
        error = None
        
        db = get_db()
        db_cursor = db.cursor()
        
        query_user = sql.SQL("SELECT * FROM {table} WHERE ecpr = %s").format(
            table=sql.Identifier('employee')
        )
        
        db_cursor.execute(query_user, (cpr,))
        result = db_cursor.fetchone()
        
        if result is None:
            error = "Forkert brugernavn eller kodeord"
        elif result[1] != password:
            error = "Forkert kodeord"
        
        if error is None:
            session.clear()
            session['user_id'] = result[0]
        else: 
            flash(error, 'danger')
                    
        return redirect(url_for('main.welcome'))
        
    return render_template('index/index.html')

@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')
    
    if user_id is None:
        g.user = None
    else:
        db = get_db()
        db_cursor = db.cursor()
        
        query_user = sql.SQL("SELECT * FROM {table} WHERE ecpr = %s").format(
            table=sql.Identifier('employee')
        )
        
        db_cursor.execute(query_user, (user_id,))
        result = db_cursor.fetchone()
        
        g.user = result


@bp.route('/logout')
def logout():
    session.clear()
    flash("Du er blevet logget ud!", 'info')
    return redirect(url_for('index.index'))

@bp.route("/404")
def pageMissing():
    return render_template("404.html")

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('index.index'))
        
        return view(**kwargs)
    
    return wrapped_view