import click
import psycopg2

from flask import current_app, g
from flask.cli import with_appcontext

# Get database object
def get_db():
    if 'db' not in g:
        g.db = psycopg2.connect(
            dbname="",
            user="",
            host="",
            port="",
            password=""
        )
        
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    
    if db is not None:
        db.cursor().close()
        db.close()
    
def init_db():
    db = get_db()
    db_cur = db.cursor()
    
    with current_app.open_resource('sql/schema.sql') as f:
        db_cur.execute(f.read().decode('utf-8'))
    
    db.commit()

def ins_data():
    db = get_db()
    db_cur = db.cursor()
    
    with current_app.open_resource('sql/insert_employee.sql') as f:
        db_cur.execute(f.read().decode('utf-8'))
        
    with current_app.open_resource('sql/insert_patient.sql') as f:
        db_cur.execute(f.read().decode('utf-8'))
    
    with current_app.open_resource('sql/insert_ingredient.sql') as f:
        db_cur.execute(f.read().decode('utf-8'))
    
    with current_app.open_resource('sql/insert_meal_recipe.sql') as f:
        db_cur.execute(f.read().decode('utf-8'))
        
        
    db.commit()

def drop_public_schema():
    db = get_db()
    db_cur = db.cursor()
    
    with current_app.open_resource('sql/drop_public_schema.sql') as f:
        db_cur.execute(f.read().decode('utf-8'))
    
    db.commit()
        
@click.command('drop-schema')
@with_appcontext
def drop_public_schema_command():
    """Drop public schema"""
    drop_public_schema()
    click.echo("Dropped and reinstantated public schema, run \'init-db\' in order to restore tables")

@click.command('init-db')
@with_appcontext
def init_db_command():
    """Clear the exisiting data and create new tables."""
    init_db()
    click.echo('Initialized the database.')
    
@click.command('ins-data')
@with_appcontext
def ins_data_command():
    """Insert data into the database"""
    ins_data()
    click.echo('Inserted data')

def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
    app.cli.add_command(ins_data_command)
    app.cli.add_command(drop_public_schema_command)