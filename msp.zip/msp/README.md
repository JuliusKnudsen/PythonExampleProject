 name# Running the prototype
## Databse setup
This guide assumes that you've created a postgres database that you have access to.
Remember to enter the correct database-information in the file `db.py`

```python
def get_db():
    if 'db' not in g:
        g.db = psycopg2.connect(
            dbname="",
            user="",
            host="",
            port="",
            password=""
        )
```

## Dependencies
Please install the following dependencies using `pip3` but do **not** do it now.
```
click==7.1.2
Flask_Bootstrap==3.3.7.1
psycopg2==2.8.5
Flask==1.1.2
flask_nav==0.6
```

## Running guide 

1. Ensure that the `msp` directory if directly visible from the current path
2. Create a virtual environment named `venv` with `python -m venv venv`, if you don't have `venv` you can find a guide on how to install it [here](https://gist.github.com/Geoyi/d9fab4f609e9f75941946be45000632b). Your python executable might not be named `python` in that case try using `py` or `python3`
3. Activate the virual environment using `source venv/bin/activate`
4. **Install the dependencies** using `pip install -r requirements.txt`
4. Run the command `export FLASK_APP=msp`
5. Run the command `export FLASK_ENV=development`
6. Deactivate and activate the environment! **THIS IS VERY IMPORTANT**
6. Run `flask init-db` to instantiate the database with the needed tables
7. Run `flask ins-data` to insert some dummy data
8. Finally, run `flask run` to start the application.

You can log in using `000000-0000` as login and `admin` as password!