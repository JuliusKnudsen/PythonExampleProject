INSERT INTO public.recipe (bodytext) 
VALUES
    ('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin quis mi quis orci consequat euismod aliquam sed purus. Donec lacinia, turpis nec porttitor posuere, lacus diam sodales erat, sed pharetra urna ligula eu nisl. Curabitur neque tellus, mollis quis consectetur nec, imperdiet id ligula. Mauris et ultricies mi. Sed quis interdum ipsum, sed congue lectus. Nam nec est lorem. In et metus lorem. Duis congue accumsan orci non pellentesque. Pellentesque commodo aliquam ante. Duis tristique non lacus et rhoncus. Vivamus ut ullamcorper turpis. Curabitur interdum tellus in finibus egestas.'),
    ('Integer varius volutpat sem, varius laoreet libero elementum at. Nulla a massa in ipsum tristique hendrerit. Vestibulum tincidunt magna a risus mattis venenatis quis et est. Vivamus gravida finibus euismod. Cras dignissim nibh nisl, porttitor consectetur magna lacinia a. Donec auctor tincidunt suscipit. Suspendisse pulvinar nisl nec ornare porta. Integer mi orci, aliquet in malesuada ac, volutpat id sem. '),
    (' Donec vitae eros sed sapien venenatis auctor et nec purus. Sed et odio arcu. Fusce vestibulum nibh eu imperdiet lacinia. Aenean risus odio, consectetur non orci at, mattis lacinia nulla. Ut hendrerit varius finibus. Pellentesque tincidunt urna nulla, at eleifend velit molestie cursus. Donec eget purus commodo, tempor lectus eget, interdum ligula. Morbi ac magna dui. Nullam sit amet ex sit amet lacus posuere faucibus tempus a magna. Sed sed diam eget augue mollis consequat vel non nisl. Duis dignissim pharetra viverra. Duis suscipit convallis lectus ut tempor. Etiam pulvinar nisl enim, vel posuere est aliquam vel. Nullam eget elit eget nisi finibus aliquet. '),
    (' Nam pulvinar lectus a felis aliquam, ut elementum sem tempus. Phasellus lacinia ut massa quis eleifend. Curabitur volutpat, arcu eu congue euismod, nulla augue feugiat est, sed vestibulum nibh dolor pharetra ante. Vivamus ut pulvinar felis. Donec condimentum fringilla lorem, eu aliquet felis facilisis eu. Integer eu dolor diam. Praesent pharetra nibh vitae sapien semper, et ornare justo rhoncus. Phasellus porta velit a ipsum rutrum viverra. Morbi eu ornare dolor. Pellentesque quis lobortis dolor, id vehicula ex. Fusce vulputate mauris metus, dignissim gravida massa porttitor et. Maecenas leo ligula, ullamcorper nec volutpat quis, tristique nec leo. Proin faucibus pellentesque velit, vel rutrum ligula sagittis dapibus. '),
    (' Ut eleifend malesuada varius. Morbi non venenatis augue. Donec ac accumsan magna. Donec ligula lectus, placerat nec eros quis, mollis mollis turpis. Donec consequat urna nisi, ut iaculis velit gravida in. Fusce posuere, ipsum scelerisque porttitor iaculis, orci tortor molestie metus, a egestas ligula nibh blandit purus. Integer viverra, mauris at semper pharetra, tellus ipsum commodo nulla, sed posuere sapien est in ligula. Donec libero libero, consectetur eu diam non, euismod porta est. Praesent mollis dui id erat imperdiet, ut rutrum lectus tempor. ');

INSERT INTO public.meal (mname, mtype) 
VALUES
    ('Test meal 1', 'Test Type'),
    ('Test meal 2', 'Test Type'),
    ('Test meal 3', 'Test Type'),
    ('Test meal 4', 'Test Type'),
    ('Test meal 5', 'Test Type');

INSERT INTO public.ingredient_recipe (amount, iid, rid)
VALUES
    (10, 1, 1),
    (66, 2, 1),
    (1, 3, 1),
    (30, 4, 1),
    (20, 6, 1),
    (10, 1, 2),
    (20, 4, 2),
    (10, 3, 2),
    (140, 5, 3),
    (1, 1, 3),
    (110, 4, 3),
    (10, 1, 4),
    (10, 2, 4),
    (10, 3, 4),
    (10, 4, 4),
    (10, 5, 4),
    (10, 6, 4),
    (102, 1, 5),
    (101, 5, 5);

INSERT INTO public.employee_meals (mid, ecpr)
VALUES
    (1, '000000-0000'),
    (2, '000000-0000'),
    (3, '000000-0000'),
    (4, '000000-0000'),
    (5, '000000-0000');

INSERT INTO public.meal_recipe(mid, rid)
VALUES
    (1,1),
    (2,2),
    (3,3),
    (4,4),
    (5,5);
    
INSERT INTO public.dietaryplan (dtitle, dtype)
VALUES
    ('Test kostplan 1', 'Test Type'),
    ('Test kostplan 2', 'Test Type');

INSERT INTO public.meal_dietaryplan (mid, did)
VALUES
    (1, 1),
    (2, 1),
    (5, 1),
    (3, 2),
    (2, 2),
    (4, 2);