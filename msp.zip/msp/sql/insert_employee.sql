INSERT INTO public.employee (eCPR, pass, efirstname, elastname)
VALUES
	('110525-7606', 'uLJYP5IQDzH2vrbh', 'Freja', 'Poulsen'),
	('251150-3190', '6g8PwKzMQFAR0OoN', 'Valdemar', 'Pedersen'),
	('310378-8191', 'IouMeGRQDhWVOjEp', 'Anna', 'Nielsen'),
	('071253-2864', 'TRIaMhcSltLKy9ri', 'Agnes', 'Pedersen'),
	('160416-8069', 'EYT0I9n0VqjHDRe1', 'Arthur', 'Jørgensen'),
	('060926-2383', '5opsLqF2cmSZ1AwI', 'Isabella', 'Mortensen'),
	('161029-0758', 'X2vMPSr0E9YyqH6U', 'Anna', 'Madsen'),
	('010255-2395', 'B1hv8rYAUVDiI79c', 'Victor', 'Christensen'),
	('190552-7207', '8bE3UFW2cYluGr1A', 'Alma', 'Nielsen'),
	('000000-0000', 'admin', 'admin', 'admin'),
	('270222-3940', 'iaq0FAcKlsuLtjXb', 'Malthe', 'Hansen');

