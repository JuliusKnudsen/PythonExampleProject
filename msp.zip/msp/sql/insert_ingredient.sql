INSERT INTO public.ingredient (iname, carbohydrates, protein, fats)
VALUES
    ('Agurk', 1, 20, 5),
    ('Tomat', 2, 20, 5),
    ('Majs', 3, 20, 5),
    ('Grønkål', 4, 20, 5),
    ('Rødkål', 5, 20, 10),
    ('Yoghurt', 6, 20, 20),
    ('Mælk', 7, 20, 30),
    ('Mel', 8, 20, 40),
    ('Sukker', 9, 20, 11),
    ('Vand', 10, 20, 21),
    ('Kylling', 11, 20, 123),
    ('Oksekød', 12, 20, 1),
    ('Laks', 13, 20, 2);