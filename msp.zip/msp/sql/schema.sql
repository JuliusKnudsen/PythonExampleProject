DROP TABLE IF EXISTS public.employee CASCADE;
DROP TABLE IF EXISTS public.dietaryplan CASCADE;
DROP TABLE IF EXISTS public.meal CASCADE;
DROP TABLE IF EXISTS public.patient CASCADE;
DROP TABLE IF EXISTS public.recipe CASCADE;
DROP TABLE IF EXISTS public.ingredient CASCADE;
DROP TABLE IF EXISTS public.vitamin CASCADE;
DROP TABLE IF EXISTS public.mineral CASCADE;
DROP TABLE IF EXISTS public.ingredient_recipe;
DROP TABLE IF EXISTS public.mineral_ingredient;
DROP TABLE IF EXISTS public.vitamin_ingredient;
DROP TABLE IF EXISTS public.meal_recipe;
DROP TABLE IF EXISTS public.patient_dietaryplan;
DROP TABLE IF EXISTS public.employee_dietaryplan;
DROP TABLE IF EXISTS public.employee_meals;
DROP TABLE IF EXISTS public.meal_dietaryplan;

DROP TRIGGER IF EXISTS CheckPlans ON patient_dietaryplan;
DROP FUNCTION  IF EXISTS trigger_function cascade;


/*
 *  ENTITY TABLES
 */

CREATE TABLE public.employee(
    eCPR VARCHAR(11),
    pass VARCHAR(16) not null,
    efirstName VARCHAR(30),
    elastName VARCHAR(30),
    PRIMARY KEY (eCPR)
);
CREATE TABLE public.patient(
    pCPR CHAR(11),
    pfirstName VARCHAR(30),
    plastName VARCHAR(30),
    pemployee VARCHAR(11) REFERENCES employee(eCPR),
    PRIMARY KEY (pCPR)
);
CREATE TABLE public.meal(
    mID SERIAL,
    mName VARCHAR(30) not null,
    mType VARCHAR(30),
    PRIMARY KEY (mID)
);
CREATE TABLE public.dietaryplan(
    dID SERIAL,
    dTitle VARCHAR(30) UNIQUE,
    dType VARCHAR(30),
    PRIMARY KEY (dID)
);
CREATE TABLE public.recipe(
    rID SERIAL,
    bodyText TEXT not null,
    PRIMARY KEY (rID)
);
CREATE TABLE public.ingredient(
    iID SERIAL,
    iName VARCHAR(30) UNIQUE,
    carbohydrates INTEGER not null,
    protein INTEGER not null,
    fats INTEGER not null,
    PRIMARY KEY (iID)
);
CREATE TABLE public.mineral(
    mineralName VARCHAR(30),
    PRIMARY KEY (mineralName)
);
CREATE TABLE public.vitamin(
    vitaminName VARCHAR(30),
    PRIMARY KEY (vitaminName)
);
/*
 *  RELATIONS
 */
CREATE TABLE public.ingredient_recipe(
    amount INTEGER not null,
    iID INTEGER,
    rID INTEGER,
    FOREIGN KEY (iID) REFERENCES ingredient(iID),
    FOREIGN KEY (rID) REFERENCES recipe(rID)
);
CREATE TABLE public.mineral_ingredient(
    amount INTEGER not null,
    iID INTEGER,
    mineralName VARCHAR(30),
    FOREIGN KEY (iID) REFERENCES ingredient(iID),
    FOREIGN KEY (mineralName) REFERENCES mineral(mineralName)
);
CREATE TABLE public.vitamin_ingredient(
    amount INTEGER not null,
    iID INTEGER,
    vitaminName VARCHAR(30),
    FOREIGN KEY (iID) REFERENCES ingredient(iID),
    FOREIGN KEY (vitaminName) REFERENCES vitamin(vitaminName)
);
CREATE TABLE public.meal_recipe(
    mID INTEGER,
    rID INTEGER,
    UNIQUE (mID),
    UNIQUE (rID),
    FOREIGN KEY (mID) REFERENCES meal(mID) ON DELETE CASCADE,
    FOREIGN KEY (rID) REFERENCES recipe(rID)
);
CREATE TABLE public.meal_dietaryplan(
    mID INTEGER,
    dID INTEGER,
    FOREIGN KEY (mID) REFERENCES meal(mID) ON DELETE CASCADE,
    FOREIGN KEY (dID) REFERENCES dietaryplan(dID)
);
CREATE TABLE public.employee_meals(
    mID INTEGER,
    eCPR VARCHAR(11),
    FOREIGN KEY (mID) REFERENCES meal(mID) ON DELETE CASCADE,
    FOREIGN KEY (eCPR) REFERENCES employee(eCPR)
);
CREATE TABLE public.employee_dietaryplan(
    eCPR VARCHAR(11),
    dID INTEGER,
    FOREIGN KEY (eCPR) REFERENCES employee(eCPR),
    FOREIGN KEY (dID) REFERENCES dietaryplan(dID)
);
CREATE TABLE public.patient_dietaryplan(
    dID INTEGER,
    pCPR VARCHAR(11),
    FOREIGN KEY (pCPR) REFERENCES patient(pCPR),
    FOREIGN KEY (dID) REFERENCES dietaryplan(dID),
    UNIQUE(dID, pCPR)
);
/*
 * TRIGGERS 
 */
CREATE FUNCTION trigger_function() RETURNS trigger AS $$ BEGIN IF(
    (
        select count(pd.pcpr)
        from patient_dietaryplan pd
        group by pd.pcpr
        having pd.pcpr = new.pcpr
    ) >= 3
) THEN RAISE EXCEPTION 'CheckPlans: En patient må maks have 3 tildelte kostplaner' USING ERRCODE = '46000';
END IF;
RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER CheckPlans BEFORE
INSERT ON patient_dietaryplan FOR EACH ROW EXECUTE PROCEDURE trigger_function();